import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function Menu() {
  const cliqueMenu = (categoria) => {
    alert(`Você clicou em: ${categoria}`);
  };

  return (
    <View style={styles.menuContainer}>
      <TouchableOpacity style={styles.menuItem} onPress={() => cliqueMenu('Celulares')}>
        <Text style={styles.menuText}>Celulares</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.menuItem} onPress={() => cliqueMenu('Notebooks')}>
        <Text style={styles.menuText}>Notebooks</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.menuItem} onPress={() => cliqueMenu('Tvs')}>
        <Text style={styles.menuText}>Tvs</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.menuItem} onPress={() => cliqueMenu('Relógios')}>
        <Text style={styles.menuText}>Relógios</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  menuContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    paddingVertical: 10,
  },
  menuItem: {
    width: '45%', // Define um tamanho adequado para dividir os botões em duas colunas
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: '#D9D9D9',
    borderRadius: 5,
    alignItems: 'center',
    margin: 5, // Adiciona espaçamento entre os botões
  },
  menuText: {
    color: 'black',
    fontWeight: 'bold',
  },
});
